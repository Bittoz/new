
export const TELEGRAM_CONFIG = {
  BOT_TOKEN: '7817546965:AAHmgPXE7nayTriJEnSveiVBfxOkrO542mw',
  BOT_USERNAME: 'bittoz_bot',
  BOT_URL: 'https://t.me/bittoz_bot',
  API_URL: 'https://api.telegram.org/bot7817546965:AAHmgPXE7nayTriJEnSveiVBfxOkrO542mw'
};

export const BOT_COMMANDS = {
  START: '/start',
  HELP: '/help',
  BROWSE: '/browse',
  ORDERS: '/orders',
  BALANCE: '/balance',
  DEPOSIT: '/deposit',
  WITHDRAW: '/withdraw'
};

export const QUICK_REPLIES = {
  BROWSE_PRODUCTS: '🛍️ Browse Products',
  MY_ORDERS: '📦 My Orders',
  WALLET: '💰 Wallet',
  HELP: '❓ Help',
  NEXT: '➡️ Next',
  PREV: '⬅️ Previous',
  BUY_NOW: '🛒 Buy Now'
};
